# Archipelago-for-Agents - cross-model experiment

Tests whether the pilot finding (premature convergence detection via repertory grid) holds when agents are from genuinely different model families instead of role-played from a single Claude.

## What to read first

1. **PROTOCOL.md** - pre-registered hypotheses, design, falsification criteria. Read this first; do not change after data collection starts.
2. **SETUP.md** - step-by-step Windows setup for running the experiment.
3. **config.yaml** - all parameters in one file. Edit model IDs if OpenRouter slugs changed.

## Files

| File | Purpose |
|------|---------|
| `PROTOCOL.md` | Pre-registration document |
| `SETUP.md` | Windows setup walkthrough |
| `config.yaml` | All experiment parameters |
| `requirements.txt` | Python dependencies |
| `run_experiment.py` | Main orchestration script (with full audit logging) |
| `analyze.py` | Statistical analysis and findings generation |
| `operator_synthesis.py` | Turns raw data into human-readable insights (no API calls) |
| `render_for_coaches.py` | Coach-friendly HTML one-pagers + session guides |
| `render_for_ai_developers.py` | AI/ML audit reports + minimal library skeleton |
| `render_for_business.py` | Executive briefings + sample case |
| `export_for_paper.py` | LaTeX tables, reproducibility appendix, supplementary tarball |
| `tasks/task_*.md` | Three task briefs |
| `personas/personas.md` | 5 epistemological personas |

## Outputs (created by scripts)

| Path | Audience | Content |
|------|----------|---------|
| `results/<cell>/cell.json` | scientific | Per-cell raw data: free responses, constructs, ratings, api_calls |
| `results/run_manifest.json` | scientific | SHA-256 of code/config, model snapshot, package versions |
| `logs/api_calls/<cell>/...json` | scientific | Full audit of every API call |
| `analysis/<cell>/biplot.png` | scientific | PCA biplots |
| `analysis/FINDINGS.md` | scientific | Statistical synthesis |
| `operator_outputs/<cell>/operator_insight.json` | all | Synthesized insights: consensus, hidden disagreement, blind spots, questions |
| `coach_kit/<cell>/one_pager.html` | coaches | Interactive client-shareable briefing |
| `coach_kit/<cell>/session_guide.md` | coaches | 90-min team session walkthrough |
| `coach_kit/<cell>/facilitator_questions.md` | coaches | Questions to drive the conversation |
| `ai_audit/<cell>/audit_report.md` | AI/ML | Audit-style report with severity |
| `ai_audit/<cell>/audit_summary.json` | AI/ML | Machine-readable; gateable in CI/CD |
| `ai_audit/aggregate_dashboard.html` | AI/ML | Cross-cell dashboard |
| `ai_audit/archipelago_audit/` | AI/ML | Importable Python library skeleton |
| `executive_briefing/<cell>/briefing.md` | business | 3-page executive briefing |
| `executive_briefing/<cell>/detailed_appendix.md` | business | Full analytical appendix |
| `executive_briefing/sample_case.md` | business | Best illustrative case (sales sample) |
| `paper_outputs/table_*.tex` | scientific | LaTeX tables for paper |
| `paper_outputs/reproducibility_appendix.md` | scientific | Reproducibility appendix |
| `supplementary_materials.tar.gz` | scientific | Complete bundle for paper submission |

## Quick start

```
pip install -r requirements.txt
$env:OPENROUTER_API_KEY = "sk-or-v1-..."
python run_experiment.py --dry-run         # validate, no cost
python run_experiment.py                   # full run, ~$45, ~60 min
python analyze.py                          # statistical findings
python operator_synthesis.py               # synthesize insights (no API)
python visualizations.py                   # static PNG charts with interpretations
python visualizations_interactive.py       # interactive HTML graph (click to explore)
python render_for_coaches.py               # outputs in coach_kit/
python render_for_ai_developers.py         # outputs in ai_audit/
python render_for_business.py              # outputs in executive_briefing/
python export_for_paper.py                 # LaTeX tables, supplementary tarball
```

## What gets tested

- **10 cells:** 3 tasks × 2 conditions (with/without persona prompts) + 4 repeats on Task B
- **5 model families:** Anthropic / OpenAI / Google / DeepSeek / Moonshot
- **50 model-trials** total
- **Headline test:** does cross-model disagreement rise above pilot's 0.14-0.31 (which indicated severe premature convergence)? Predicted range: 0.6-1.5.

## When done

Send these back to Claude for joint interpretation:
- `analysis/FINDINGS.md`
- `analysis/comparison_vs_pilot.md`
- `analysis/per_cell_summary.csv`
- Any unexpected entries from `logs/run_*.log`
