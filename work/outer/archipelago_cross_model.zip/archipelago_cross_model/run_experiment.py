#!/usr/bin/env python3
"""
Archipelago-for-Agents - cross-model orchestration.

Runs the full experimental pipeline defined in PROTOCOL.md and config.yaml.
- Pre-flight checks (API key, model availability, cost estimate)
- 4-phase pipeline per cell: free response -> anonymization -> constructs -> ratings
- Resumable: checkpoints after each phase
- Cost tracking with hard stop
- Detailed logging
- Dry-run mode for validation without API spend

Run:
    python run_experiment.py                       # full run
    python run_experiment.py --dry-run             # validate config, no API calls
    python run_experiment.py --resume              # resume from last checkpoint
    python run_experiment.py --cell A_N_run1       # run only this cell

Requires OPENROUTER_API_KEY in environment.
"""
from __future__ import annotations
import argparse
import json
import os
import random
import re
import sys
import time
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime
from itertools import combinations
from pathlib import Path
from typing import Any

try:
    import yaml
    import requests
except ImportError as exc:
    print(f"Missing dependency: {exc.name}. Run: pip install -r requirements.txt")
    sys.exit(1)


# ============================================================
# Logging
# ============================================================
class Logger:
    def __init__(self, log_dir: Path):
        log_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = log_dir / f"run_{ts}.log"

    def _write(self, level: str, msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {level}: {msg}"
        print(line)
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    def info(self, msg: str) -> None: self._write("INFO", msg)
    def warn(self, msg: str) -> None: self._write("WARN", msg)
    def error(self, msg: str) -> None: self._write("ERR ", msg)
    def debug(self, msg: str) -> None: self._write("DBG ", msg)


# ============================================================
# State and checkpoint
# ============================================================
@dataclass
class CellResult:
    cell_id: str
    task: str
    condition: str
    run_idx: int
    status: str = "pending"                  # pending | running | complete | failed
    started_at: str = ""                     # ISO timestamp when cell run began
    completed_at: str = ""                   # ISO timestamp when cell run finished
    random_seed: int = 0                     # seed for triad assignment and element shuffle
    free_responses: dict = field(default_factory=dict)   # {short_name: text}
    element_mapping: dict = field(default_factory=dict)  # {En: short_name}
    element_summaries: dict = field(default_factory=dict)  # {En: summary}
    triad_assignments: dict = field(default_factory=dict)  # {short_name: [[E1,E2,E3], ...]}
    constructs: dict = field(default_factory=dict)         # {short_name: [{...}, ...]}
    ratings: dict = field(default_factory=dict)            # {short_name: {construct_id: {En: rating}}}
    # Per-call audit trail (one entry per API call across all phases)
    api_calls: list = field(default_factory=list)
    # Per-model cost/token breakdown for analysis
    per_model_cost: dict = field(default_factory=dict)   # {short_name: float}
    per_model_tokens: dict = field(default_factory=dict) # {short_name: {prompt, completion}}
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    errors: list = field(default_factory=list)


class State:
    """Tracks all cells, costs, and checkpoint persistence."""

    def __init__(self, state_file: Path):
        self.state_file = state_file
        self.cells: dict[str, CellResult] = {}
        self.total_cost_usd: float = 0.0
        self.started_at: str = ""

    def save(self) -> None:
        data = {
            "started_at": self.started_at,
            "total_cost_usd": self.total_cost_usd,
            "cells": {cid: asdict(c) for cid, c in self.cells.items()},
        }
        tmp = self.state_file.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        tmp.replace(self.state_file)

    def load(self) -> bool:
        if not self.state_file.exists():
            return False
        with open(self.state_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.started_at = data.get("started_at", "")
        self.total_cost_usd = data.get("total_cost_usd", 0.0)
        for cid, cdata in data.get("cells", {}).items():
            self.cells[cid] = CellResult(**cdata)
        return True


# ============================================================
# OpenRouter API client with retry and cost tracking
# ============================================================
class OpenRouterClient:
    def __init__(self, api_key: str, config: dict, logger: Logger):
        self.api_key = api_key
        self.base_url = config["openrouter"]["base_url"]
        self.retries = config["openrouter"]["retries_per_call"]
        self.backoff = config["openrouter"]["retry_backoff_seconds"]
        self.timeout = config["openrouter"]["request_timeout_seconds"]
        self.logger = logger
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://archplg.co.uk",
            "X-Title": "Archipelago-for-Agents experiment",
        })

    def list_models(self) -> dict[str, dict]:
        """Return mapping of model_id -> metadata (pricing, context length, etc.)."""
        r = self.session.get(f"{self.base_url}/models", timeout=self.timeout)
        r.raise_for_status()
        data = r.json().get("data", [])
        return {m["id"]: m for m in data}

    def chat(
        self,
        model_id: str,
        fallback_id: str | None,
        messages: list[dict],
        temperature: float,
        max_tokens: int,
    ) -> dict:
        """
        Return rich result dict for reproducibility logging:
        {
            "content": str,             # the text response
            "usage": dict,              # prompt_tokens, completion_tokens
            "model_id_used": str,       # which model actually responded
            "model_id_requested": str,  # the primary requested
            "used_fallback": bool,
            "attempts": int,            # how many attempts before success
            "latency_ms": int,
            "timestamp_iso": str,
            "raw_response_json": dict,  # full API response for audit
            "request_payload": dict,    # what we sent (without auth)
        }
        Raises RuntimeError if all attempts fail.
        """
        timestamp_iso = datetime.now().isoformat()
        attempt_total = 0
        last_error = None
        for model_to_try in [model_id, fallback_id] if fallback_id else [model_id]:
            if model_to_try is None:
                continue
            for attempt in range(self.retries):
                attempt_total += 1
                payload = {
                    "model": model_to_try,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                }
                start = time.monotonic()
                try:
                    r = self.session.post(
                        f"{self.base_url}/chat/completions",
                        json=payload,
                        timeout=self.timeout,
                    )
                    latency_ms = int((time.monotonic() - start) * 1000)
                    if r.status_code == 429:
                        wait = self.backoff[min(attempt, len(self.backoff) - 1)]
                        self.logger.warn(f"Rate limit on {model_to_try}, wait {wait}s")
                        time.sleep(wait)
                        last_error = f"HTTP 429 after {latency_ms}ms"
                        continue
                    if r.status_code >= 400:
                        self.logger.warn(
                            f"{model_to_try} HTTP {r.status_code}: {r.text[:300]}"
                        )
                        last_error = f"HTTP {r.status_code}: {r.text[:300]}"
                        if attempt < self.retries - 1:
                            time.sleep(self.backoff[attempt])
                            continue
                        break
                    data = r.json()
                    content = data["choices"][0]["message"]["content"]
                    usage = data.get("usage", {})
                    return {
                        "content": content,
                        "usage": usage,
                        "model_id_used": model_to_try,
                        "model_id_requested": model_id,
                        "used_fallback": model_to_try != model_id,
                        "attempts": attempt_total,
                        "latency_ms": latency_ms,
                        "timestamp_iso": timestamp_iso,
                        "raw_response_json": data,
                        "request_payload": payload,
                    }
                except (requests.RequestException, KeyError) as exc:
                    latency_ms = int((time.monotonic() - start) * 1000)
                    last_error = f"{type(exc).__name__}: {exc}"
                    self.logger.warn(
                        f"{model_to_try} attempt {attempt+1} error: {exc}"
                    )
                    if attempt < self.retries - 1:
                        time.sleep(self.backoff[attempt])
            self.logger.warn(f"Primary {model_to_try} exhausted, trying fallback")
        raise RuntimeError(f"All attempts failed for {model_id}; last error: {last_error}")


# ============================================================
# Cost calculation
# ============================================================
def calculate_cost(usage: dict, model_meta: dict) -> float:
    """Estimate USD cost from usage dict and OpenRouter pricing metadata."""
    pricing = model_meta.get("pricing", {})
    # OpenRouter returns prices as strings, USD per token
    prompt_price = float(pricing.get("prompt", "0") or "0")
    completion_price = float(pricing.get("completion", "0") or "0")
    pt = usage.get("prompt_tokens", 0)
    ct = usage.get("completion_tokens", 0)
    return pt * prompt_price + ct * completion_price


def record_api_call(
    cell: CellResult,
    phase: str,
    short_name: str,
    persona_or_neutral: str,
    sys_prompt: str,
    user_prompt: str,
    api_result: dict,
    cost: float,
    parsed_summary: str,
    config: dict,
) -> None:
    """
    Persist a single API call to disk for reproducibility and pejabat audit.
    Each call writes a complete JSON to logs/api_calls/<cell>/<phase>_<model>_<n>.json
    AND appends a compact record to cell.api_calls (in-memory + state.json).
    """
    audit_dir = Path(config["experiment"]["log_dir"]) / "api_calls" / cell.cell_id
    audit_dir.mkdir(parents=True, exist_ok=True)
    # Number this call's file (so retries do not overwrite)
    existing = list(audit_dir.glob(f"{phase}_{short_name}_*.json"))
    n = len(existing) + 1
    audit_file = audit_dir / f"{phase}_{short_name}_{n:02d}.json"

    full_record = {
        "cell_id": cell.cell_id,
        "task": cell.task,
        "condition": cell.condition,
        "run_idx": cell.run_idx,
        "phase": phase,
        "model_short_name": short_name,
        "persona_or_neutral": persona_or_neutral,
        "system_prompt": sys_prompt,
        "user_prompt": user_prompt,
        "model_id_requested": api_result["model_id_requested"],
        "model_id_used": api_result["model_id_used"],
        "used_fallback": api_result["used_fallback"],
        "attempts": api_result["attempts"],
        "latency_ms": api_result["latency_ms"],
        "timestamp_iso": api_result["timestamp_iso"],
        "raw_response_content": api_result["content"],
        "raw_response_full": api_result["raw_response_json"],
        "usage": api_result["usage"],
        "cost_usd": cost,
        "parsed_summary": parsed_summary,
        "request_payload": api_result["request_payload"],
    }
    with open(audit_file, "w", encoding="utf-8") as f:
        json.dump(full_record, f, indent=2, ensure_ascii=False)

    # Compact version into cell.api_calls (everything except full raw payloads)
    cell.api_calls.append({
        "phase": phase,
        "model_short_name": short_name,
        "persona_or_neutral": persona_or_neutral,
        "model_id_used": api_result["model_id_used"],
        "used_fallback": api_result["used_fallback"],
        "attempts": api_result["attempts"],
        "latency_ms": api_result["latency_ms"],
        "timestamp_iso": api_result["timestamp_iso"],
        "prompt_tokens": api_result["usage"].get("prompt_tokens", 0),
        "completion_tokens": api_result["usage"].get("completion_tokens", 0),
        "cost_usd": cost,
        "audit_file": str(audit_file.relative_to(Path(config["experiment"]["log_dir"]).parent)),
    })


# ============================================================
# Persona prompts
# ============================================================
PERSONA_PROMPTS = {
    "Q": (
        "You are an analyst with a quantitative-empiricist epistemological frame. "
        "You prefer measurable evidence and falsifiable claims, and you are skeptical "
        "of frameworks that cannot be operationalized. Your default question is 'what "
        "is the data?'. Your decision heuristic is expected value under uncertainty "
        "with explicit confidence intervals. Generate analysis from this frame."
    ),
    "S": (
        "You are an analyst with a systems-strategist epistemological frame. "
        "You think in feedback loops, second-order effects, and long horizons. "
        "You see the situation as a network of interacting forces, not a set of "
        "options. Your decision heuristic is to identify leverage points and avoid "
        "actions that increase systemic fragility. Generate analysis from this frame."
    ),
    "E": (
        "You are an analyst with a first-principles-engineering epistemological "
        "frame. You reduce to fundamentals. You ask 'what is the actual mechanism?'. "
        "You are suspicious of analogy and prefer efficient, minimal solutions. "
        "Your decision heuristic is to identify the binding constraint, address "
        "it directly, ignore the rest. Generate analysis from this frame."
    ),
    "H": (
        "You are an analyst with a humanist-ethicist epistemological frame. "
        "You center stakeholders, dignity, and distributional consequences. "
        "You see economic framings as incomplete. Your default question is "
        "'who is affected and how?'. Your decision heuristic is to minimize "
        "unjustified harm to vulnerable parties, then optimize. Generate analysis "
        "from this frame."
    ),
    "C": (
        "You are an analyst with a contrarian-skeptic epistemological frame. "
        "You identify hidden assumptions and ask 'what if everyone is wrong?'. "
        "You are a devil's advocate by construction. Your decision heuristic is "
        "to prefer reversible moves and to trust the contrarian signal in "
        "unanimous consensus. Generate analysis from this frame."
    ),
}

NEUTRAL_PROMPT = (
    "You are an analyst. Read the brief carefully and provide your best-reasoned "
    "recommendation."
)


# ============================================================
# Triad assignment - balanced across agents
# ============================================================
def assign_triads(n_agents: int, n_elements: int, n_triads_per_agent: int, seed: int) -> list[list[tuple[int, ...]]]:
    """
    Return list of length n_agents; each element is a list of n_triads_per_agent
    triads. A triad is a tuple of 3 element indices (0..n_elements-1).
    Tries to spread triads across all C(n_elements, 3) combinations.
    """
    rng = random.Random(seed)
    all_triads = list(combinations(range(n_elements), 3))
    # Repeat list to have enough triads
    needed = n_agents * n_triads_per_agent
    pool = list(all_triads) * ((needed // len(all_triads)) + 1)
    rng.shuffle(pool)
    assignments = []
    for i in range(n_agents):
        agent_triads = pool[i * n_triads_per_agent : (i + 1) * n_triads_per_agent]
        assignments.append(agent_triads)
    return assignments


# ============================================================
# Phase implementations
# ============================================================
def load_task_brief(task_id: str, config: dict) -> str:
    for t in config["tasks"]:
        if t["id"] == task_id:
            with open(t["brief_file"], "r", encoding="utf-8") as f:
                return f.read()
    raise KeyError(f"Task {task_id} not found in config")


def get_system_prompt(model_short_name: str, task_id: str, condition_cfg: dict) -> str:
    if not condition_cfg["use_personas"]:
        return condition_cfg["system_prompt"]
    persona_id = condition_cfg["persona_assignment"][task_id][model_short_name]
    return PERSONA_PROMPTS[persona_id]


def _persona_id_for(short_name: str, task_id: str, condition_cfg: dict) -> str:
    if not condition_cfg["use_personas"]:
        return "neutral"
    return condition_cfg["persona_assignment"][task_id][short_name]


def phase1_free_response(
    cell: CellResult,
    config: dict,
    client: OpenRouterClient,
    model_meta: dict[str, dict],
    state: State,
    logger: Logger,
) -> None:
    """Each model generates a free-form recommendation."""
    logger.info(f"[{cell.cell_id}] Phase 1: free response")
    task_brief = load_task_brief(cell.task, config)
    condition_cfg = next(c for c in config["conditions"] if c["id"] == cell.condition)
    params = config["parameters"]["free_response"]

    for model in config["models"]:
        sn = model["short_name"]
        if sn in cell.free_responses:
            continue
        sys_prompt = get_system_prompt(sn, cell.task, condition_cfg)
        user_msg = (
            f"{task_brief}\n\n"
            "Provide your recommendation in 200-400 words. Advocate for a "
            "specific position; do not enumerate all options."
        )
        try:
            res = client.chat(
                model_id=model["id"],
                fallback_id=model.get("fallback_id"),
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": user_msg},
                ],
                temperature=params["temperature"],
                max_tokens=params["max_tokens"],
            )
            cell.free_responses[sn] = res["content"]
            cost = calculate_cost(res["usage"], model_meta.get(res["model_id_used"], {}))
            cell.cost_usd += cost
            cell.tokens_in += res["usage"].get("prompt_tokens", 0)
            cell.tokens_out += res["usage"].get("completion_tokens", 0)
            cell.per_model_cost[sn] = cell.per_model_cost.get(sn, 0.0) + cost
            pmt = cell.per_model_tokens.setdefault(sn, {"prompt": 0, "completion": 0})
            pmt["prompt"] += res["usage"].get("prompt_tokens", 0)
            pmt["completion"] += res["usage"].get("completion_tokens", 0)
            state.total_cost_usd += cost
            record_api_call(
                cell, "phase1_freeresponse", sn,
                _persona_id_for(sn, cell.task, condition_cfg),
                sys_prompt, user_msg, res, cost,
                parsed_summary=f"free_response captured ({len(res['content'])} chars)",
                config=config,
            )
            logger.info(
                f"  {sn} ({res['model_id_used']}{'/FB' if res['used_fallback'] else ''}) "
                f"ok, {res['latency_ms']}ms, ${cost:.4f}"
            )
            state.save()
        except Exception as exc:
            cell.errors.append(f"phase1 {sn}: {exc}")
            logger.error(f"  {sn}: {exc}")
            state.save()


def phase2_anonymize(cell: CellResult, logger: Logger) -> None:
    """Shuffle responses, label E1-E5, generate summaries."""
    if cell.element_mapping:
        return
    logger.info(f"[{cell.cell_id}] Phase 2: anonymize")
    short_names = list(cell.free_responses.keys())
    rng = random.Random(hash(cell.cell_id) % (2 ** 32))
    rng.shuffle(short_names)
    cell.element_mapping = {f"E{i+1}": sn for i, sn in enumerate(short_names)}
    # Generate short summaries (first 3 sentences of each response)
    for ek, sn in cell.element_mapping.items():
        text = cell.free_responses[sn]
        sentences = re.split(r"(?<=[.!?])\s+", text)
        summary = " ".join(sentences[:3]).strip()
        if len(summary) > 600:
            summary = summary[:600] + "..."
        cell.element_summaries[ek] = summary


def _parse_constructs(text: str, expected_count: int) -> list[dict]:
    """Parse model output for triadic constructs.
    Expected format includes 'left:' and 'right:' poles per construct."""
    constructs = []
    blocks = re.split(r"\n\s*(?:Triad|TRIAD|##)\s*\d+", "\n" + text)
    for block in blocks[1:]:
        left_match = re.search(r"[Ll]eft[ -]?[Pp]ole\s*[:\-]\s*(.+)", block)
        right_match = re.search(r"[Rr]ight[ -]?[Pp]ole\s*[:\-]\s*(.+)", block)
        if left_match and right_match:
            left = left_match.group(1).strip().split("\n")[0].strip()
            right = right_match.group(1).strip().split("\n")[0].strip()
            constructs.append({"left": left, "right": right})
    if len(constructs) >= expected_count:
        return constructs[:expected_count]
    # Fallback: looser parse - look for "X vs Y" patterns
    if not constructs:
        for line in text.split("\n"):
            m = re.search(r"^\s*\d*[\.\)]?\s*(.+?)\s*(?:↔|<->|vs\.?|<>)\s*(.+)$", line, re.IGNORECASE)
            if m:
                left, right = m.group(1).strip(), m.group(2).strip()
                # filter out obviously bogus matches
                if 3 <= len(left) <= 120 and 3 <= len(right) <= 120:
                    constructs.append({"left": left, "right": right})
    return constructs[:expected_count]


def phase3_constructs(
    cell: CellResult,
    config: dict,
    client: OpenRouterClient,
    model_meta: dict[str, dict],
    state: State,
    logger: Logger,
) -> None:
    """Each model produces N constructs via triadic elicitation."""
    logger.info(f"[{cell.cell_id}] Phase 3: triadic construct elicitation")
    n_triads = config["pipeline"]["n_triads_per_agent"]
    n_elements = config["pipeline"]["n_elements"]
    seed = hash(cell.cell_id) % (2 ** 32)
    triad_assignments = assign_triads(
        n_agents=len(config["models"]),
        n_elements=n_elements,
        n_triads_per_agent=n_triads,
        seed=seed,
    )
    params = config["parameters"]["constructs"]

    condition_cfg = next(c for c in config["conditions"] if c["id"] == cell.condition)
    elements_block = "\n\n".join(
        f"**{ek}:** {cell.element_summaries[ek]}"
        for ek in sorted(cell.element_summaries.keys())
    )

    for i, model in enumerate(config["models"]):
        sn = model["short_name"]
        if sn in cell.constructs and len(cell.constructs[sn]) >= n_triads:
            continue
        sys_prompt = get_system_prompt(sn, cell.task, condition_cfg)
        my_triads = triad_assignments[i]
        cell.triad_assignments[sn] = [
            [f"E{idx+1}" for idx in triad] for triad in my_triads
        ]
        triad_list_text = "\n".join(
            f"Triad {ti+1}: {', '.join(f'E{idx+1}' for idx in triad)}"
            for ti, triad in enumerate(my_triads)
        )
        user_msg = (
            f"You are presented with 5 anonymous responses to the same brief. "
            f"They are labeled E1 through E5.\n\n"
            f"{elements_block}\n\n"
            f"Your task: for each of the following triads of 3 responses, "
            f"identify a single bipolar construct that distinguishes them. "
            f"Specifically, identify how TWO of the three are similar to each "
            f"other in a way that distinguishes them from the THIRD. Name the "
            f"two poles of that dimension.\n\n"
            f"Triads to analyze:\n{triad_list_text}\n\n"
            f"For each triad, output EXACTLY this format:\n"
            f"Triad N:\nLeft pole: <short phrase, max 12 words>\n"
            f"Right pole: <short phrase, max 12 words>\n\n"
            f"Be specific. Avoid generic dichotomies like 'good vs bad'."
        )
        try:
            res = client.chat(
                model_id=model["id"],
                fallback_id=model.get("fallback_id"),
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": user_msg},
                ],
                temperature=params["temperature"],
                max_tokens=params["max_tokens"],
            )
            content = res["content"]
            parsed = _parse_constructs(content, n_triads)
            if len(parsed) < n_triads:
                cell.errors.append(
                    f"phase3 {sn}: parsed only {len(parsed)} constructs from output"
                )
                logger.warn(f"  {sn}: parsed {len(parsed)}/{n_triads} - keeping what we got")
            cell.constructs[sn] = [
                {"id": f"C_{sn}_{j+1}", "left": c["left"], "right": c["right"],
                 "triad": cell.triad_assignments[sn][j] if j < len(cell.triad_assignments[sn]) else None,
                 "raw_output_excerpt": content[:200]}
                for j, c in enumerate(parsed)
            ]
            cost = calculate_cost(res["usage"], model_meta.get(res["model_id_used"], {}))
            cell.cost_usd += cost
            cell.tokens_in += res["usage"].get("prompt_tokens", 0)
            cell.tokens_out += res["usage"].get("completion_tokens", 0)
            cell.per_model_cost[sn] = cell.per_model_cost.get(sn, 0.0) + cost
            pmt = cell.per_model_tokens.setdefault(sn, {"prompt": 0, "completion": 0})
            pmt["prompt"] += res["usage"].get("prompt_tokens", 0)
            pmt["completion"] += res["usage"].get("completion_tokens", 0)
            state.total_cost_usd += cost
            record_api_call(
                cell, "phase3_constructs", sn,
                _persona_id_for(sn, cell.task, condition_cfg),
                sys_prompt, user_msg, res, cost,
                parsed_summary=f"parsed {len(parsed)}/{n_triads} constructs",
                config=config,
            )
            logger.info(
                f"  {sn} ({res['model_id_used']}{'/FB' if res['used_fallback'] else ''}) "
                f"ok, {len(parsed)} constructs, {res['latency_ms']}ms, ${cost:.4f}"
            )
            state.save()
        except Exception as exc:
            cell.errors.append(f"phase3 {sn}: {exc}")
            logger.error(f"  {sn}: {exc}")
            state.save()


def _parse_ratings(text: str, construct_ids: list[str], element_labels: list[str]) -> dict:
    """Extract integer ratings 1-7 from model output. Tolerates various formats."""
    out: dict[str, dict[str, int]] = {}
    for cid in construct_ids:
        out[cid] = {}
    # Look for lines like "C_M1_1, E1: 5" or "C_M1_1 E1=5" or CSV-like
    pattern = re.compile(
        r"(C_[A-Z0-9_]+)\s*[,\s|:]\s*(E[1-9])\s*[=:\-,]\s*([1-7])"
    )
    for match in pattern.finditer(text):
        cid, ek, val = match.group(1), match.group(2), int(match.group(3))
        if cid in out and ek in element_labels:
            out[cid][ek] = val
    # Also try CSV-style table parse: "C_xx,1,5,3,7,2"
    csv_pattern = re.compile(
        r"(C_[A-Z0-9_]+)\s*[,|\t]\s*([1-7])\s*[,|\t]\s*([1-7])\s*[,|\t]\s*([1-7])\s*[,|\t]\s*([1-7])\s*[,|\t]\s*([1-7])"
    )
    for match in csv_pattern.finditer(text):
        cid = match.group(1)
        if cid in out:
            for i, ek in enumerate(element_labels):
                if ek not in out[cid]:
                    out[cid][ek] = int(match.group(i + 2))
    return out


def phase4_ratings(
    cell: CellResult,
    config: dict,
    client: OpenRouterClient,
    model_meta: dict[str, dict],
    state: State,
    logger: Logger,
) -> None:
    """Each model rates all 5 elements on all collected constructs."""
    logger.info(f"[{cell.cell_id}] Phase 4: ratings")
    # Aggregate ALL constructs from all agents
    all_constructs = []
    for sn in sorted(cell.constructs.keys()):
        all_constructs.extend(cell.constructs[sn])
    if not all_constructs:
        logger.warn(f"  no constructs to rate")
        return
    construct_ids = [c["id"] for c in all_constructs]
    element_labels = sorted(cell.element_summaries.keys())
    params = config["parameters"]["ratings"]
    condition_cfg = next(c for c in config["conditions"] if c["id"] == cell.condition)
    elements_block = "\n\n".join(
        f"**{ek}:** {cell.element_summaries[ek]}" for ek in element_labels
    )
    constructs_block = "\n".join(
        f"  {c['id']}: '{c['left']}'  (1) ↔ (7)  '{c['right']}'"
        for c in all_constructs
    )

    for model in config["models"]:
        sn = model["short_name"]
        if sn in cell.ratings and len(cell.ratings[sn]) >= len(construct_ids):
            continue
        sys_prompt = get_system_prompt(sn, cell.task, condition_cfg)
        user_msg = (
            f"You are presented with 5 anonymous responses (E1-E5) and a set of "
            f"bipolar constructs. Rate each response on each construct on a "
            f"1-7 scale, where 1 = strongly the LEFT pole and 7 = strongly the "
            f"RIGHT pole. 4 = neutral or mixed.\n\n"
            f"Responses:\n{elements_block}\n\n"
            f"Constructs to rate (id : left pole ↔ right pole):\n{constructs_block}\n\n"
            f"Output ONE line per (construct, element) pair, in this exact format:\n"
            f"<construct_id>,<element>,<rating>\n\n"
            f"Example:\nC_M1_1,E1,5\nC_M1_1,E2,3\n...\n\n"
            f"Produce {len(construct_ids) * len(element_labels)} lines total. "
            f"No commentary, only the lines."
        )
        try:
            res = client.chat(
                model_id=model["id"],
                fallback_id=model.get("fallback_id"),
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": user_msg},
                ],
                temperature=params["temperature"],
                max_tokens=params["max_tokens"],
            )
            content = res["content"]
            parsed = _parse_ratings(content, construct_ids, element_labels)
            cell.ratings[sn] = parsed
            # Count missing
            expected = len(construct_ids) * len(element_labels)
            got = sum(len(v) for v in parsed.values())
            if got < expected:
                cell.errors.append(
                    f"phase4 {sn}: got {got}/{expected} ratings"
                )
                logger.warn(f"  {sn}: parsed {got}/{expected} ratings")
            cost = calculate_cost(res["usage"], model_meta.get(res["model_id_used"], {}))
            cell.cost_usd += cost
            cell.tokens_in += res["usage"].get("prompt_tokens", 0)
            cell.tokens_out += res["usage"].get("completion_tokens", 0)
            cell.per_model_cost[sn] = cell.per_model_cost.get(sn, 0.0) + cost
            pmt = cell.per_model_tokens.setdefault(sn, {"prompt": 0, "completion": 0})
            pmt["prompt"] += res["usage"].get("prompt_tokens", 0)
            pmt["completion"] += res["usage"].get("completion_tokens", 0)
            state.total_cost_usd += cost
            record_api_call(
                cell, "phase4_ratings", sn,
                _persona_id_for(sn, cell.task, condition_cfg),
                sys_prompt, user_msg, res, cost,
                parsed_summary=f"parsed {got}/{expected} ratings",
                config=config,
            )
            logger.info(
                f"  {sn} ({res['model_id_used']}{'/FB' if res['used_fallback'] else ''}) "
                f"ok, {got}/{expected} ratings, {res['latency_ms']}ms, ${cost:.4f}"
            )
            state.save()
        except Exception as exc:
            cell.errors.append(f"phase4 {sn}: {exc}")
            logger.error(f"  {sn}: {exc}")
            state.save()


# ============================================================
# Cells: enumerate all (task, condition, run_idx) cells per protocol
# ============================================================
def enumerate_cells(config: dict) -> list[tuple[str, str, int]]:
    cells = []
    for task in config["tasks"]:
        for cond in config["conditions"]:
            cells.append((task["id"], cond["id"], 1))
        if task.get("is_repeat_task"):
            extra = config["repetitions"]["extra_runs_for_repeat_task"]
            for cond in config["conditions"]:
                for k in range(2, 2 + extra):
                    cells.append((task["id"], cond["id"], k))
    return cells


def cell_id(task: str, cond: str, run_idx: int) -> str:
    return f"{task}_{cond}_run{run_idx}"


# ============================================================
# Pre-flight
# ============================================================
def preflight(config: dict, client: OpenRouterClient, logger: Logger) -> dict[str, dict]:
    logger.info("Pre-flight checks")
    pf = config["preflight"]
    model_meta: dict[str, dict] = {}
    if pf["verify_model_ids"]:
        try:
            available = client.list_models()
        except Exception as exc:
            logger.error(f"Cannot reach OpenRouter: {exc}")
            raise
        logger.info(f"  {len(available)} models available on OpenRouter")
        for m in config["models"]:
            for mid in [m["id"], m.get("fallback_id")]:
                if mid and mid in available:
                    model_meta[mid] = available[mid]
                elif mid:
                    logger.warn(f"  {mid} NOT FOUND in OpenRouter catalog")
        for m in config["models"]:
            if m["id"] not in model_meta and m.get("fallback_id") not in model_meta:
                raise RuntimeError(
                    f"Both primary ({m['id']}) and fallback ({m.get('fallback_id')}) "
                    f"unavailable. Update config.yaml."
                )
    if pf["estimate_cost"]:
        cells = enumerate_cells(config)
        n_trials = len(cells) * len(config["models"])
        # Heuristic per trial: ~10K input + 1.5K output (worst case)
        avg_in = 10000
        avg_out = 1500
        total_cost = 0.0
        for m in config["models"]:
            mid = m["id"] if m["id"] in model_meta else m.get("fallback_id")
            if mid and mid in model_meta:
                pr = model_meta[mid].get("pricing", {})
                p_in = float(pr.get("prompt", "0") or "0")
                p_out = float(pr.get("completion", "0") or "0")
                # 3 phases per trial
                trial_cost = (avg_in * p_in + avg_out * p_out) * 3
                total_cost += trial_cost * len(cells)
                logger.info(
                    f"  {m['short_name']} ({mid}): "
                    f"${p_in*1e6:.2f}/M in, ${p_out*1e6:.2f}/M out, "
                    f"est ${trial_cost*len(cells):.2f} total"
                )
        logger.info(f"  {len(cells)} cells x {len(config['models'])} models = {n_trials} trials")
        logger.info(f"  Estimated total cost: ${total_cost:.2f}")
        logger.info(f"  Hard cap: ${config['experiment']['total_budget_usd']}")
        if total_cost > config["experiment"]["total_budget_usd"]:
            logger.error("Estimated cost exceeds hard cap.")
            raise RuntimeError("Cost cap exceeded in estimate. Aborting.")
    return model_meta


# ============================================================
# Main run loop
# ============================================================
def run_cell(
    cell: CellResult,
    config: dict,
    client: OpenRouterClient,
    model_meta: dict[str, dict],
    state: State,
    logger: Logger,
) -> None:
    cell.status = "running"
    cell.started_at = datetime.now().isoformat()
    # Capture the seed actually used (was computed inline before, now recorded)
    cell.random_seed = hash(cell.cell_id) % (2 ** 32)
    state.save()
    try:
        phase1_free_response(cell, config, client, model_meta, state, logger)
        phase2_anonymize(cell, logger)
        phase3_constructs(cell, config, client, model_meta, state, logger)
        phase4_ratings(cell, config, client, model_meta, state, logger)
        cell.status = "complete" if not cell.errors else "complete_with_errors"
    except Exception as exc:
        logger.error(f"[{cell.cell_id}] cell failed: {exc}")
        logger.error(traceback.format_exc())
        cell.status = "failed"
        cell.errors.append(f"cell-level: {exc}")
    cell.completed_at = datetime.now().isoformat()
    state.save()
    save_cell_artifacts(cell, config)


def save_cell_artifacts(cell: CellResult, config: dict) -> None:
    out_dir = Path(config["experiment"]["output_dir"]) / cell.cell_id
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "cell.json", "w", encoding="utf-8") as f:
        json.dump(asdict(cell), f, indent=2, ensure_ascii=False)


def _file_sha256(path: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def write_run_manifest(config: dict, model_meta: dict, config_path: str) -> None:
    """
    Writes a manifest file with everything needed for reproducibility:
    - script and config SHA-256 hashes
    - model_meta snapshot at run start (prices, context windows)
    - python and package versions
    - all 10 cell IDs to be run
    - timezone and start time
    """
    import platform
    out_dir = Path(config["experiment"]["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_file = out_dir / "run_manifest.json"

    script_path = Path(__file__).resolve()
    analyze_path = script_path.parent / "analyze.py"

    # Capture installed package versions for the libraries we depend on
    pkg_versions = {}
    for pkg in ["requests", "yaml", "pandas", "numpy",
                "sklearn", "scipy", "matplotlib", "seaborn"]:
        try:
            mod = __import__(pkg)
            pkg_versions[pkg] = getattr(mod, "__version__", "unknown")
        except Exception:
            pkg_versions[pkg] = "not-installed"

    manifest = {
        "run_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "started_at": datetime.now().isoformat(),
        "timezone": time.strftime("%Z"),
        "script_sha256": _file_sha256(script_path),
        "config_sha256": _file_sha256(Path(config_path)),
        "analyze_sha256": _file_sha256(analyze_path) if analyze_path.exists() else None,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "package_versions": pkg_versions,
        "experiment_name": config["experiment"]["name"],
        "total_budget_usd": config["experiment"]["total_budget_usd"],
        "estimated_budget_usd": config["experiment"]["estimated_budget_usd"],
        "n_models": len(config["models"]),
        "n_tasks": len(config["tasks"]),
        "n_conditions": len(config["conditions"]),
        "cells_planned": [cell_id(t, c, r) for t, c, r in enumerate_cells(config)],
        "models_snapshot": [
            {
                "short_name": m["short_name"],
                "family": m["family"],
                "primary_id": m["id"],
                "fallback_id": m.get("fallback_id"),
                "primary_pricing": model_meta.get(m["id"], {}).get("pricing", {}),
                "primary_context_length": model_meta.get(m["id"], {}).get("context_length"),
            }
            for m in config["models"]
        ],
        "config_full_snapshot": config,
    }
    with open(manifest_file, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False, default=str)
    return manifest_file


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--cell", default=None, help="Run only this cell (id like A_N_run1)")
    args = p.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    if args.dry_run:
        config["preflight"]["dry_run_mode"] = True

    logger = Logger(Path(config["experiment"]["log_dir"]))
    logger.info(f"Archipelago cross-model run starting")
    logger.info(f"Config: {args.config}")

    api_key = os.environ.get(config["openrouter"]["api_key_env"])
    if not api_key and not args.dry_run:
        logger.error(
            f"Set {config['openrouter']['api_key_env']} environment variable "
            f"(e.g., in PowerShell: $env:OPENROUTER_API_KEY=\"sk-or-...\")."
        )
        return 2

    client = OpenRouterClient(api_key or "dry-run", config, logger)

    try:
        model_meta = preflight(config, client, logger)
    except Exception as exc:
        logger.error(f"Pre-flight failed: {exc}")
        return 3

    if args.dry_run:
        logger.info("DRY RUN complete - no API spend.")
        return 0

    if config["preflight"]["require_user_confirmation"]:
        ans = input(
            "Proceed with the full experiment? Type YES to confirm: "
        ).strip()
        if ans != "YES":
            logger.info("Aborted by user.")
            return 0

    # Write reproducibility manifest BEFORE first API call
    manifest_file = write_run_manifest(config, model_meta, args.config)
    logger.info(f"Wrote reproducibility manifest: {manifest_file}")

    state_file = Path(config["experiment"]["output_dir"]) / "state.json"
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state = State(state_file)
    if args.resume and state.load():
        logger.info(f"Resumed: total cost so far ${state.total_cost_usd:.2f}")
    else:
        state.started_at = datetime.now().isoformat()

    cells_to_run = enumerate_cells(config)
    if args.cell:
        cells_to_run = [(t, c, r) for (t, c, r) in cells_to_run if cell_id(t, c, r) == args.cell]
        if not cells_to_run:
            logger.error(f"Cell {args.cell} not found. Available:")
            for t, c, r in enumerate_cells(config):
                logger.error(f"  {cell_id(t, c, r)}")
            return 4

    for task, cond, run_idx in cells_to_run:
        cid = cell_id(task, cond, run_idx)
        if cid not in state.cells:
            state.cells[cid] = CellResult(cell_id=cid, task=task, condition=cond, run_idx=run_idx)
        cell = state.cells[cid]
        if cell.status in ("complete", "complete_with_errors") and not args.cell:
            logger.info(f"[{cid}] already complete, skipping")
            continue
        if state.total_cost_usd > config["experiment"]["total_budget_usd"]:
            logger.error(f"BUDGET HARD STOP at ${state.total_cost_usd:.2f}")
            return 5
        run_cell(cell, config, client, model_meta, state, logger)
        logger.info(f"[{cid}] done. cell cost: ${cell.cost_usd:.4f}. total: ${state.total_cost_usd:.4f}")

    logger.info(f"All cells processed. Final cost: ${state.total_cost_usd:.4f}")
    logger.info(f"Output: {config['experiment']['output_dir']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
